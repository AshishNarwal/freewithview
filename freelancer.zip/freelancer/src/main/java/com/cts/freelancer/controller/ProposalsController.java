package com.cts.freelancer.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Proposals;
import com.cts.freelancer.service.ProposalsService;
import com.cts.freelancer.service.UserLoginService;

@Controller
public class ProposalsController {
	
	@Autowired
	ProposalsService proposalService;
	
	@Autowired
	UserLoginService userLogin;
	
	@RequestMapping(value="propose",method=RequestMethod.GET)
	public ModelAndView addProposal(@RequestParam ("projectId") int projectId,@SessionAttribute ("adminId") String emailID)
	{
		//int projectId1=Integer.parseInt(projectId);
		System.out.println("ProjectId ="+projectId);
		ModelAndView modelAndView=new ModelAndView();
		//HttpSession session1=request.getSession(true);
		//String lancerEmail=(String)session1.getAttribute("adminId");
		System.out.println("User EmailId in Controller from request ="+emailID);
		int lancerId=userLogin.getUserId(emailID);
		System.out.println("User Id ="+lancerId);
		Proposals proposal=new Proposals();
		proposal.setLancerId(lancerId);
		proposal.setProjectId(projectId);
	    boolean result=proposalService.addProposal(projectId , lancerId);
	    if(result)
	    {
	    	modelAndView.addObject("projectId",projectId);
	    	modelAndView.setViewName("proposalAdded");
	    }
	    else
	    {
	    	modelAndView.setViewName("error");
	    }
		return modelAndView;
	}
	
	  
    @RequestMapping(value="accept",method=RequestMethod.GET)
    public ModelAndView acceptProposal(@RequestParam ("projectId") String project,@RequestParam ("lancerId") String lancer,HttpServletRequest request)
    {
    	System.out.println(" projectId ="+project+" lancerId ="+lancer+" from jsp page");
    	ModelAndView modelAndView=new ModelAndView();
    	//int adminId=(int)request.getAttribute("adminId");
    	int lancerId=Integer.parseInt(lancer);
    	int projectId=Integer.parseInt(project);
    	System.out.println(" projectId = "+projectId);
    	boolean result=proposalService.acceptOffer(projectId,lancerId);
    	if(result)
    	{
    		modelAndView.addObject("projectId", projectId);
    		modelAndView.addObject("lancerId",lancerId);
//    		modelAndView.addObject("adminId",adminId);
    		modelAndView.setViewName("offerAccepted");
    	}
    	else
    	{
    		modelAndView.setViewName("error");
    	}
    	return modelAndView;
    }
    
    
    @RequestMapping(value="showstatus",method=RequestMethod.GET)
    public ModelAndView offerStatus(@RequestParam ("projectId") String project,@RequestParam ("userId") String lancer)
    {
    	ModelAndView modelAndView=new ModelAndView();
    	int projectId=Integer.parseInt(project);
    	int lancerId=Integer.parseInt(lancer);
    	boolean result=proposalService.offerStatus(projectId, lancerId);
    	if(result)
    	{
    		modelAndView.setViewName("offerStatus1");
    		modelAndView.addObject("projectId",projectId);
    	}
    	else
    	{
    		modelAndView.setViewName("offerStatus2");
    		modelAndView.addObject("projectId",projectId);
    	}
    	return modelAndView;
    	
    }

}
