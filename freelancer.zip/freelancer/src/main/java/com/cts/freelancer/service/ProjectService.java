package com.cts.freelancer.service;

import com.cts.freelancer.bean.Project;

public interface ProjectService {

	public boolean registerProject(Project project);
}
