package com.cts.freelancer.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.User;


@Repository("userLoginDAO")
public class UserLoginDAOImpl implements UserLoginDAO{

	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@Transactional
	public boolean authenticate(String emailId, String password) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from User where emailId=? and password=?");
		query.setParameter(0,emailId);
		query.setParameter(1, password);
		User user=(User)query.getSingleResult();
		if(user==null)
		return false;
		else
			return true;
	}

    @Transactional
	public boolean registerUser(User user) {
		// TODO Auto-generated method stub
    	Session session=null;
    	
    	try{
    		session=sessionFactory.getCurrentSession();
    		session.save(user);
    		return true;
    	}catch(Exception e)
    	{
    		e.printStackTrace();
    		return false;
    	}
	}

//    @Transactional
//	public List<Project> showProjects(String emailId) {
//		// TODO Auto-generated method stub
//    	List<Project> projectList=new ArrayList<Project>();
//    	Session session=null;
//    	try
//    	{
//    		User user=getUserSkills(emailId);
//    		session=sessionFactory.getCurrentSession();
//    		Query query=session.createQuery("from Project where skill1=? and skill2=? and skill3=? and skill4=? and skill5=? and skill6=? and skill7=? and skill8=? and skill9=? and skill10=?");
//    		query.setParameter(0,user.getSkill1());
//    		query.setParameter(1,user.getSkill2());
//    		query.setParameter(2,user.getSkill3());
//    		query.setParameter(3,user.getSkill4());
//    		query.setParameter(4,user.getSkill5());
//    		query.setParameter(5,user.getSkill6());
//    		query.setParameter(6,user.getSkill7());
//    		query.setParameter(7,user.getSkill8());
//    		query.setParameter(8,user.getSkill9());
//    		query.setParameter(9,user.getSkill10());
//    		
//            System.out.println(user.getSkill1()+" "+user.getSkill2());
//    		projectList=query.getResultList();
//    		System.out.println("Number of matching projects = "+projectList.size());
//    	}catch(Exception e)
//    	{
//    		e.printStackTrace();
//    	}
//    	
//		return projectList;
//	}
    @Transactional
    public List<Project> showProjects(String emailId)
    {
     List<Project> projectList=new ArrayList<Project>();
     //Set<Project> pro=new HashSet<Project>();
     Session session=null;
     try
     {
    	 
    	 User user=getUserSkills(emailId);
    	 System.out.println("Returned user emailId = "+user.getEmailId()+" and userId ="+user.getUserId());
    	 session=sessionFactory.getCurrentSession();
    	 List<String> skills=new ArrayList<String>();
    	 
    	 String skill1=user.getSkill1();
    	 String skill2=user.getSkill2();
    	 String skill3=user.getSkill3();
    	 String skill4=user.getSkill4();
    	 String skill5=user.getSkill5();
    	 String skill6=user.getSkill6();
    	 String skill7=user.getSkill7();
    	 String skill8=user.getSkill8();
    	 String skill9=user.getSkill9();
    	 String skill10=user.getSkill10();
    	 
    	 if(skill1.equals("PHP"))
    		 skills.add(skill1);
    	 if(skill2.equals("HTML"))
    		 skills.add(skill2);
    	 if(skill3.equals("Javascript"))
    		 skills.add(skill3);
    	 if(skill4.equals("MySQL"))
    		 skills.add(skill4);
    	 if(skill5.equals("Java"))
    		 skills.add(skill5);
    	 if(skill6.equals("Python"))
    		 skills.add(skill6);
    	 if(skill7.equals(".NET"))
    		 skills.add(skill7);
    	 if(skill8.equals("Angular.js"))
    		 skills.add(skill8);
    	 if(skill9.equals("Unity 3D"))
    		 skills.add(skill8);
    	 if(skill10.equals("Laravel"))
    		 skills.add(skill10);
    	 
    	 int count=skills.size();
    	 System.out.println("Skill List size =" +count);
          for(String s:skills)
        	  System.out.println(s);
    	List<Project> allProjects=getAllProject();
    	
    	for(Project pro:allProjects)
    	{
    		List<String> proSkills=projectSkills(pro);
    		int size=0;
    		for(String skil:proSkills)
    		{
    			if(skills.contains(skil))
    				size++;
    		}
    		if(size==proSkills.size())
    			projectList.add(pro);
    	}
    	 
     }
     catch(Exception e)
     {
    	 e.printStackTrace();
     }
     return projectList;
    }
    

    @Transactional
	public User getUserSkills(String emailId) {
		// TODO Auto-generated method stub
    	Session session=sessionFactory.getCurrentSession();
    	Query query=session.createQuery("from User where emailId=?");
    	query.setParameter(0,emailId);
    	User user=(User)query.getSingleResult();
		return user;
	}

	@Transactional
	public int getUserId(String emailId) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from User where emailId=?");
		query.setParameter(0,emailId);
		User user=(User)query.getSingleResult();
		System.out.println("Returned LancerId + "+user.getUserId());
		return user.getUserId();
	}

	@Transactional
	public boolean updateSkills(String emailId, List<String> skillList) {
		// TODO Auto-generated method stub
		Session session=null;
		try
		{
			session=sessionFactory.getCurrentSession();
			String skill1=skillList.get(0);
			String skill2=skillList.get(1);
			String skill3=skillList.get(2);
			String skill4=skillList.get(3);
			String skill5=skillList.get(4);
			String skill6=skillList.get(5);
			String skill7=skillList.get(6);
			String skill8=skillList.get(7);
			String skill9=skillList.get(8);
			String skill10=skillList.get(9);
			System.out.println("Skills in DAO "+skill1+" "+skill2+" "+skill3+" "+skill4+" "+skill5+" "+skill6+" "+skill7+" "+skill8+" "+skill9+" "+skill10);
			System.out.println("User id in DAO ="+emailId);
			Query query=session.createQuery("from User where emailId=?");
			query.setParameter(0,emailId);
			
			User user=(User)query.getSingleResult();
			System.out.println("user id fetched from database " + user.getUserId() );
               
				user.setSkill1(skill1);
				System.out.println("Skill1 after setting"+user.getSkill1());
			
				user.setSkill2(skill2);
				System.out.println("Skill2 after setting"+user.getSkill2());	
			
				user.setSkill3(skill3);
				System.out.println("Skill3 after setting"+user.getSkill3());
			
			user.setSkill4(skill4);
			System.out.println("Skill4 after setting"+user.getSkill4());

				user.setSkill5(skill5);
				System.out.println("Skill5 after setting"+user.getSkill5());
			
				user.setSkill6(skill6);
				System.out.println("Skill6 after setting"+user.getSkill6());
				user.setSkill7(skill7);
				System.out.println("Skill7 after setting"+user.getSkill7());

				user.setSkill8(skill8);
				System.out.println("Skill8 after setting"+user.getSkill8());
			
				user.setSkill9(skill9);
				System.out.println("Skill9 after setting"+user.getSkill9());
			
				user.setSkill10(skill10);
				System.out.println("Skill10 after setting"+user.getSkill10());
			
			
			
			
			//session.update(user);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Transactional
	public boolean logout() {
		// TODO Auto-generated method stub
		HttpSession session=null;
		try
		{
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	@javax.transaction.Transactional
	public List<Project> getAllProject() {
		// TODO Auto-generated method stub
		List<Project> allProjects=new ArrayList<>();
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Project");
		allProjects=query.getResultList();
		return allProjects;
	}
	
	
	@javax.transaction.Transactional
	public List<String> projectSkills(Project project)
	{
		List<String> skills=new ArrayList<>();
		if(project.getSkill1().equals("PHP"))
   		 skills.add(project.getSkill1());
   	 if(project.getSkill2().equals("HTML"))
   		 skills.add(project.getSkill2());
   	 if(project.getSkill3().equals("Javascript"))
   		 skills.add(project.getSkill3());
   	 if(project.getSkill4().equals("MySQL"))
   		 skills.add(project.getSkill4());
   	 if(project.getSkill5().equals("Java"))
   		 skills.add(project.getSkill5());
   	 if(project.getSkill6().equals("Python"))
   		 skills.add(project.getSkill6());
   	 if(project.getSkill7().equals(".NET"))
   		 skills.add(project.getSkill7());
   	 if(project.getSkill8().equals("Angular.js"))
   		 skills.add(project.getSkill8());
   	 if(project.getSkill9().equals("Unity 3D"))
   		 skills.add(project.getSkill9());
   	 if(project.getSkill10().equals("Laravel"))
   		 skills.add(project.getSkill10());
		return skills;
	}
}
