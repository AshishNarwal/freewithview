package com.cts.freelancer.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.User;
import com.cts.freelancer.service.UserLoginService;

@Controller
public class UserController {
	
	@Autowired
	UserLoginService userLogin;
	
	@RequestMapping(value="registerUser",method=RequestMethod.GET)
	public ModelAndView registerUser(@ModelAttribute User user)
	{
		ModelAndView modelAndView=new ModelAndView();
		boolean result=userLogin.registerUser(user);
		if(result)
		{
			modelAndView.setViewName("userLogin");
		}
		else
		{	
			modelAndView.setViewName("error");
		}
		return modelAndView;
	}
	
	
	@RequestMapping(value="userLoginAuth",method=RequestMethod.POST)
	public ModelAndView loginUser(@RequestParam ("emailId") String emailId,@RequestParam ("password") String password,HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		List<Project> projectList=new ArrayList<Project>(); 
		boolean result=userLogin.authenticate(emailId, password);
		if(result)
		{
			HttpSession session1=request.getSession(true);
			int userId=userLogin.getUserId(emailId);
			projectList=userLogin.showProjects(emailId);
			System.out.println(projectList.size());
			System.out.println(emailId);
			session1.setAttribute("emailId",emailId);
			session1.setAttribute("userId",userLogin.getUserId(emailId));
			modelAndView.setViewName("userWelcome");
			modelAndView.addObject("emailId", emailId);
			modelAndView.addObject("projectList",projectList);
		}
		else
		{
			modelAndView.setViewName("error");
		}
		return modelAndView;
	}
	
	
	@RequestMapping(value="updateSkills",method=RequestMethod.GET)
	public ModelAndView addSkills(HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		String skill1 = request.getParameter("skill1");
		String skill2=request.getParameter("skill2");
		String skill3=request.getParameter("skill3");
		String skill4=request.getParameter("skill4");
		String skill5=request.getParameter("skill5");
		String skill6=request.getParameter("skill6");
		String skill7=request.getParameter("skill7");
		String skill8=request.getParameter("skill8");
		String skill9=request.getParameter("skill9");
		String skill10=request.getParameter("skill10");
		//String emailId=request.getParameter("emailId");
		String emailId=(String)request.getSession().getAttribute("emailId");
		System.out.println("User Id ="+request.getAttribute("userId"));
		System.out.println("User Email Id "+emailId);
		System.out.println("skills " +skill1+" "+skill2+" "+skill3+" "+skill4+" "+skill5+" "+skill6+" "+skill7+" "+skill8+" "+skill9+" "+skill10);
		//System.out.println("Skills "+skill1+" "+skill2+" "+skill3+" "+skill4+" "+skill5+" "+skill6+" "+skill7+" "+skill8+" "+skill9+" "+skill10);
		List<String> skillList=new ArrayList<>();
		skillList.add(skill1);
		skillList.add(skill2);
		skillList.add(skill3);
		skillList.add(skill4);
		skillList.add(skill5);
		skillList.add(skill6);
		skillList.add(skill7);
		skillList.add(skill8);
		skillList.add(skill9);
		skillList.add(skill10);
		
		boolean result=userLogin.updateSkills(emailId, skillList);
		if(result)
		{
		modelAndView.setViewName("skillAdded");
		modelAndView.addObject("skillList",skillList);
		}
		else
			modelAndView.setViewName("error");
		return modelAndView;
	}
}
