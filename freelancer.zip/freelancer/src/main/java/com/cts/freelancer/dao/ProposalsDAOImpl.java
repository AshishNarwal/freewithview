package com.cts.freelancer.dao;


import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.AcceptedOffers;
import com.cts.freelancer.bean.Proposals;

@Repository("ProposalsDAO")
public class ProposalsDAOImpl implements ProposalsDAO{
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@javax.transaction.Transactional
	public boolean addProposal(int projectId, int lancerId) {
		// TODO Auto-generated method stub
		Session session=null;
	
			session=sessionFactory.getCurrentSession();
			System.out.println("Project Id = "+projectId+"  Lancer Id = "+lancerId);
			
			
			Query query=session.createQuery("from Proposals where projectId=? and lancerId=?");
			query.setParameter(0,projectId);
			query.setParameter(1,lancerId);
		  try
		  {
			Proposals proposals=(Proposals)query.getSingleResult();
		    System.out.println("LancerId = "+proposals.getLancerId()+" ProjectId ="+proposals.getProjectId()+" ProposalId ="+proposals.getProposalId());
		      
		  }catch(NoResultException e)
			{
			    Proposals proposal=new Proposals();
				proposal.setLancerId(lancerId);
				proposal.setProjectId(projectId);
				session.save(proposal);
				return true;
			}
		
		return false;
	}

	@javax.transaction.Transactional
	public boolean acceptOffer(int projectId, int lancerId) {
		// TODO Auto-generated method stub
		Session session=null;
		boolean result;
		try
		{
			session=sessionFactory.getCurrentSession();
			AcceptedOffers offer=new AcceptedOffers();
//			offer.setAdminId(adminId);
			offer.setLancerId(lancerId);
			offer.setProjectId(projectId);
			Query query=session.createQuery("from AcceptedOffers where projectId=? and lancerId=?");
			query.setParameter(0,projectId);
			query.setParameter(1,lancerId);
			AcceptedOffers offer1=(AcceptedOffers)query.getSingleResult();
			if(offer1==null)
			{
				session.save(offer);
		    return true;	
			}
			else
				return false;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	@javax.transaction.Transactional
	public boolean offerStatus(int projectId,int lancerId)
	{
		Session session=null;
		//boolean result;
		try
		{
			session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from AcceptedOffers where projectId=? and lancerId=?");
			query.setParameter(0, projectId);
			query.setParameter(1,lancerId);
			AcceptedOffers offer=(AcceptedOffers)query.getSingleResult();
			if(offer==null)
				return false;
			else 
				return true;
		}
		catch(NoResultException e)
		{
			e.printStackTrace();
		}
		return false;
	}
	

}
