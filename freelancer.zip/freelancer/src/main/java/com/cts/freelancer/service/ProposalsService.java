package com.cts.freelancer.service;

public interface ProposalsService {

	public boolean addProposal(int projectId, int lancerId);
	public boolean acceptOffer(int projectId,int lancerId);
	public boolean offerStatus(int projectId,int lancerId);
}
