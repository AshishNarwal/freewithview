package com.cts.freelancer.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class AcceptedOffers {
	private int projectId;
//	private int adminId;
	private int lancerId;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int offerId;
	
	


public AcceptedOffers(){}




public int getProjectId() {
	return projectId;
}




public void setProjectId(int projectId) {
	this.projectId = projectId;
}




//public int getAdminId() {
//	return adminId;
//}
//
//
//
//
//public void setAdminId(int adminId) {
//	this.adminId = adminId;
//}
//



public int getLancerId() {
	return lancerId;
}




public void setLancerId(int lancerId) {
	this.lancerId = lancerId;
}




public int getOfferId() {
	return offerId;
}




public void setOfferId(int offerId) {
	this.offerId = offerId;
}



}