package com.cts.freelancer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.dao.ProposalsDAO;

@Service("ProposalsService")
@Transactional(propagation=Propagation.SUPPORTS)
public class ProposalsServiceImpl implements ProposalsService{

	@Autowired
	ProposalsDAO proposalsDAO;
	
	public boolean addProposal(int projectId, int lancerId) {
		// TODO Auto-generated method stub
		return proposalsDAO.addProposal(projectId, lancerId);
	}

	
	public boolean acceptOffer(int projectId, int lancerId) {
		// TODO Auto-generated method stub
		return proposalsDAO.acceptOffer(projectId, lancerId);
	}
	
	public boolean offerStatus(int projectId,int lancerId)
	{
		return proposalsDAO.offerStatus(projectId, lancerId);
	}


}
