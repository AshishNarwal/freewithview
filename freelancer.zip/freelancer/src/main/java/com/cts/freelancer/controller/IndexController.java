package com.cts.freelancer.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController {
	
	@RequestMapping(value="/")
	public String welcomePage()
	{
		return "welcome";
	}
    
	
	@RequestMapping(value="admin")
	public String getAdminForm()
	{
		return "adminRegisterForm";
	}
	
	@RequestMapping(value="lancer")
	public String lancerForm()
	{
		return "lancerRegisterForm";
	}
	
	@RequestMapping(value="userLoginPage")
	public String userLoginPage()
	{
		return "userLogin";
	}
	
	@RequestMapping(value="editAdmin",method=RequestMethod.GET)
	public ModelAndView editAdminpage(@RequestParam ("emailId") String emailId)
	{
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("editAdmin");
		modelAndView.addObject("emailId",emailId);
		return modelAndView;
	}
//	@RequestMapping(value="editAdmin")
//	public String editAdminpage()
//	{
//		return "editAdmin";
//	}
	
	@RequestMapping(value="editUser",method=RequestMethod.GET)
	public ModelAndView addSkillsPage(@RequestParam ("emailId") String emailId,HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		//request.getSession().setAttribute("emailId",emailId);
		modelAndView.setViewName("addSkills");
		modelAndView.addObject("emailId",emailId);
		return modelAndView;
	}
	
	
	@RequestMapping(value="logout",method=RequestMethod.POST)
	public ModelAndView logout(@RequestParam ("emailId") String emailId)
	{
		ModelAndView modelAndView=new ModelAndView();
		boolean result;
		return modelAndView;
	}
}
