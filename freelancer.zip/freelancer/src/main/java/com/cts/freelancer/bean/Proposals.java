package com.cts.freelancer.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;

@Entity
@Table
@DynamicInsert(value=true)
public class Proposals {

	private int projectId;
	private int lancerId;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int proposalId;
	
	public int getProposalId() {
		return proposalId;
	}


	public void setProposalId(int proposalId) {
		this.proposalId = proposalId;
	}


	public Proposals(){}
	
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public int getLancerId() {
		return lancerId;
	}
	public void setLancerId(int lancerId) {
		this.lancerId = lancerId;
	}
	@Override
	public String toString() {
		return "Proposals [projectId=" + projectId + ", lancerId=" + lancerId + "]";
	}
	
	
}
